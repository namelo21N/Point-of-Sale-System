﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace POS_Project
{
    internal class Data
    {
        private readonly string _ConnectionString;
        public Data()
        {
            _ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["processSaleConnectionString"].ConnectionString;

        }

        internal List<Product> Search(string productName)
        {
            var products = new List<Product>();
            using (SqlConnection cn = new SqlConnection(_ConnectionString))
            {
                cn.Open();
                
                    using (SqlCommand cmd = new SqlCommand(@"Select [ProductID]      
      ,[Name]
      ,[Selling_Price]
      ,[Unit_In_Stock]      
       from [GroupWst8].[dbo].[Product] where Name like '%' + @Name + '%'", cn))
                    {
                        cmd.Parameters.AddWithValue("@Name", productName);
                        SqlDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            var product = new Product
                            {
                                ProductId = (int)reader["ProductID"],
                                ProductName = (string)reader["Name"],
                                Price = (decimal)reader["Selling_Price"],
                                NumberOfItemsInStock = (int)reader["Unit_In_Stock"]
                            };
                            products.Add(product);
                        }
                    reader.Close();
                        cn.Close();
                        return products;
                    }
               
            }
        }

        internal Customer SearchCustomer(string email)
        {            
            using (SqlConnection cn = new SqlConnection(_ConnectionString))
            {
                cn.Open();

                using (SqlCommand cmd = new SqlCommand(@"Select TOP 1 [CustomerID]
      ,[First_Name]
      ,[Last_Name]
      ,[Email_Address]
      ,[City_Name]    
       from [GroupWst8].[dbo].[Customer] where Email_Address = @Email", cn))
                {
                    cmd.Parameters.AddWithValue("@Email", email);
                    SqlDataReader reader = cmd.ExecuteReader();
                    reader.Read();
                    var customer = new Customer
                    {
                        CustomerId = (int)reader["CustomerID"],
                        FirstName = (string)reader["First_Name"],
                        Surname = (string)reader["Last_Name"],
                        Email = (string)reader["Email_Address"],
                        City = (string)reader["City_Name"]
                    };
                    reader.Close();
                    cn.Close();
                    return customer;
                }

            }
        }

        internal void PlaceOrder(int customerId, int employeeId, List<OrderLine> orderLines)
        {
            DataTable items = OrderLinesToDataTable(orderLines);
            using(var connection = new SqlConnection(_ConnectionString))
            {
                connection.Open();
                var command = new SqlCommand("pr_PlaceOrder", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter { ParameterName = "@CustomerID", Value = customerId, SqlDbType = SqlDbType.Int });
                command.Parameters.Add(new SqlParameter { ParameterName = "@EmployeeID", Value = employeeId, SqlDbType = SqlDbType.Int });
                var orderLinesParam = new SqlParameter
                {
                    Value = items,
                    ParameterName = "@OrderLines",
                    SqlDbType = SqlDbType.Structured,
                    TypeName = "dbo.ut_OrderLine"
                };
                command.Parameters.Add(orderLinesParam);                
                command.ExecuteNonQuery();
                connection.Close();
            }
        }

        private DataTable OrderLinesToDataTable(List<OrderLine> orderLines)
        {
            var table = new DataTable("ut_OrderLine");
            table.Columns.Add(new DataColumn { DataType = typeof(int), ColumnName = "ProductID",  });
            table.Columns.Add(new DataColumn { DataType = typeof(int), ColumnName = "Quantity" });
            table.Columns.Add(new DataColumn { DataType = typeof(decimal), ColumnName = "PricePerUnit" });
            table.Columns.Add(new DataColumn { DataType = typeof(decimal), ColumnName = "TotalPrice" });
            orderLines.ForEach(order =>
            {
                table.Rows.Add(order.ProductId, order.Quantity, order.PricePerItem, order.TotalPrice);

            });
            return table;
        }
    }
}
