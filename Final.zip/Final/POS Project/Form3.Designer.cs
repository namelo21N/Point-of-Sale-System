﻿using System;

namespace POS_Project
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.panel6 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.lblChange = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Cost = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.NewCustomer = new System.Windows.Forms.Button();
            this.Pay = new System.Windows.Forms.Button();
            this.Remove = new System.Windows.Forms.Button();
            this.Print = new System.Windows.Forms.Button();
            this.Reset = new System.Windows.Forms.Button();
            this.Availability = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblTotalInvoicePrice = new System.Windows.Forms.Label();
            this.lblVat = new System.Windows.Forms.Label();
            this.lblSubTotalInvoicePrice = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.ProdList = new System.Windows.Forms.TabPage();
            this.btnAddToInvoice = new System.Windows.Forms.Button();
            this.txtQuantity = new System.Windows.Forms.TextBox();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblProductName = new System.Windows.Forms.Label();
            this.lblProductId = new System.Windows.Forms.Label();
            this.lblUnitsInStock = new System.Windows.Forms.Label();
            this.lblActualPrice = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.dgProducts = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.gpbCustomerInfo = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lblCustomerCity = new System.Windows.Forms.Label();
            this.lblCustomerSurname = new System.Windows.Forms.Label();
            this.lblCustomerFirstName = new System.Windows.Forms.Label();
            this.txtCustomerEmail = new System.Windows.Forms.TextBox();
            this.btnSearchCustomer = new System.Windows.Forms.Button();
            this.dgInvoicing = new System.Windows.Forms.DataGridView();
            this.label9 = new System.Windows.Forms.Label();
            this.orderBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet1 = new POS_Project.DataSet1();
            this.orderTableAdapter = new POS_Project.DataSet1TableAdapters.OrderTableAdapter();
            this.orderLineBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.orderLineTableAdapter = new POS_Project.DataSet1TableAdapters.OrderLineTableAdapter();
            this.button1 = new System.Windows.Forms.Button();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.ProdList.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgProducts)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.gpbCustomerInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgInvoicing)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderLineBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Tan;
            this.panel6.Controls.Add(this.label5);
            this.panel6.Controls.Add(this.lblChange);
            this.panel6.Controls.Add(this.label6);
            this.panel6.Controls.Add(this.Cost);
            this.panel6.Location = new System.Drawing.Point(303, 306);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(344, 201);
            this.panel6.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 90);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Change";
            // 
            // lblChange
            // 
            this.lblChange.BackColor = System.Drawing.Color.Tan;
            this.lblChange.Enabled = false;
            this.lblChange.Location = new System.Drawing.Point(130, 83);
            this.lblChange.Name = "lblChange";
            this.lblChange.Size = new System.Drawing.Size(121, 20);
            this.lblChange.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 22);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(28, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Cost";
            // 
            // Cost
            // 
            this.Cost.BackColor = System.Drawing.Color.Tan;
            this.Cost.Location = new System.Drawing.Point(130, 19);
            this.Cost.Name = "Cost";
            this.Cost.Size = new System.Drawing.Size(121, 20);
            this.Cost.TabIndex = 2;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Tan;
            this.panel5.Controls.Add(this.NewCustomer);
            this.panel5.Controls.Add(this.Pay);
            this.panel5.Controls.Add(this.Remove);
            this.panel5.Controls.Add(this.Print);
            this.panel5.Controls.Add(this.Reset);
            this.panel5.Controls.Add(this.Availability);
            this.panel5.Location = new System.Drawing.Point(653, 307);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(367, 200);
            this.panel5.TabIndex = 10;
            // 
            // NewCustomer
            // 
            this.NewCustomer.BackColor = System.Drawing.Color.SaddleBrown;
            this.NewCustomer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NewCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewCustomer.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.NewCustomer.Location = new System.Drawing.Point(183, 139);
            this.NewCustomer.Name = "NewCustomer";
            this.NewCustomer.Size = new System.Drawing.Size(169, 47);
            this.NewCustomer.TabIndex = 17;
            this.NewCustomer.Text = "New Customer";
            this.NewCustomer.UseVisualStyleBackColor = false;
            this.NewCustomer.Click += new System.EventHandler(this.NewCustomer_Click_1);
            // 
            // Pay
            // 
            this.Pay.BackColor = System.Drawing.Color.SaddleBrown;
            this.Pay.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Pay.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pay.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.Pay.Location = new System.Drawing.Point(3, 3);
            this.Pay.Name = "Pay";
            this.Pay.Size = new System.Drawing.Size(169, 47);
            this.Pay.TabIndex = 12;
            this.Pay.Text = "Pay";
            this.Pay.UseVisualStyleBackColor = false;
            this.Pay.Click += new System.EventHandler(this.Pay_Click);
            // 
            // Remove
            // 
            this.Remove.BackColor = System.Drawing.Color.SaddleBrown;
            this.Remove.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Remove.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Remove.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.Remove.Location = new System.Drawing.Point(3, 71);
            this.Remove.Name = "Remove";
            this.Remove.Size = new System.Drawing.Size(169, 47);
            this.Remove.TabIndex = 14;
            this.Remove.Text = "Remove";
            this.Remove.UseVisualStyleBackColor = false;
            // 
            // Print
            // 
            this.Print.BackColor = System.Drawing.Color.SaddleBrown;
            this.Print.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Print.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Print.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.Print.Location = new System.Drawing.Point(3, 139);
            this.Print.Name = "Print";
            this.Print.Size = new System.Drawing.Size(169, 47);
            this.Print.TabIndex = 16;
            this.Print.Text = "Print";
            this.Print.UseVisualStyleBackColor = false;
            // 
            // Reset
            // 
            this.Reset.BackColor = System.Drawing.Color.SaddleBrown;
            this.Reset.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Reset.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.Reset.Location = new System.Drawing.Point(183, 0);
            this.Reset.Name = "Reset";
            this.Reset.Size = new System.Drawing.Size(169, 47);
            this.Reset.TabIndex = 13;
            this.Reset.Text = "Reset";
            this.Reset.UseVisualStyleBackColor = false;
            // 
            // Availability
            // 
            this.Availability.BackColor = System.Drawing.Color.SaddleBrown;
            this.Availability.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Availability.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Availability.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.Availability.Location = new System.Drawing.Point(183, 71);
            this.Availability.Name = "Availability";
            this.Availability.Size = new System.Drawing.Size(169, 47);
            this.Availability.TabIndex = 15;
            this.Availability.Text = "Availability";
            this.Availability.UseVisualStyleBackColor = false;
            this.Availability.Click += new System.EventHandler(this.Availability_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Tan;
            this.panel3.Controls.Add(this.lblTotalInvoicePrice);
            this.panel3.Controls.Add(this.lblVat);
            this.panel3.Controls.Add(this.lblSubTotalInvoicePrice);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Location = new System.Drawing.Point(1, 306);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(296, 201);
            this.panel3.TabIndex = 9;
            // 
            // lblTotalInvoicePrice
            // 
            this.lblTotalInvoicePrice.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotalInvoicePrice.Location = new System.Drawing.Point(110, 120);
            this.lblTotalInvoicePrice.Name = "lblTotalInvoicePrice";
            this.lblTotalInvoicePrice.Size = new System.Drawing.Size(153, 23);
            this.lblTotalInvoicePrice.TabIndex = 2;
            // 
            // lblVat
            // 
            this.lblVat.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblVat.Location = new System.Drawing.Point(110, 68);
            this.lblVat.Name = "lblVat";
            this.lblVat.Size = new System.Drawing.Size(153, 23);
            this.lblVat.TabIndex = 2;
            // 
            // lblSubTotalInvoicePrice
            // 
            this.lblSubTotalInvoicePrice.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSubTotalInvoicePrice.Location = new System.Drawing.Point(110, 12);
            this.lblSubTotalInvoicePrice.Name = "lblSubTotalInvoicePrice";
            this.lblSubTotalInvoicePrice.Size = new System.Drawing.Size(153, 23);
            this.lblSubTotalInvoicePrice.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 126);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Total";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(28, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "VAT";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Sub Total";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tabControl1);
            this.panel1.Location = new System.Drawing.Point(1, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1018, 288);
            this.panel1.TabIndex = 7;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.ProdList);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(3, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1015, 282);
            this.tabControl1.TabIndex = 0;
            // 
            // ProdList
            // 
            this.ProdList.BackColor = System.Drawing.Color.Tan;
            this.ProdList.Controls.Add(this.button1);
            this.ProdList.Controls.Add(this.btnAddToInvoice);
            this.ProdList.Controls.Add(this.txtQuantity);
            this.ProdList.Controls.Add(this.txtSearch);
            this.ProdList.Controls.Add(this.label10);
            this.ProdList.Controls.Add(this.lblPrice);
            this.ProdList.Controls.Add(this.lblProductName);
            this.ProdList.Controls.Add(this.lblProductId);
            this.ProdList.Controls.Add(this.lblUnitsInStock);
            this.ProdList.Controls.Add(this.lblActualPrice);
            this.ProdList.Controls.Add(this.label8);
            this.ProdList.Controls.Add(this.label7);
            this.ProdList.Controls.Add(this.dgProducts);
            this.ProdList.Location = new System.Drawing.Point(4, 22);
            this.ProdList.Name = "ProdList";
            this.ProdList.Padding = new System.Windows.Forms.Padding(3);
            this.ProdList.Size = new System.Drawing.Size(1007, 256);
            this.ProdList.TabIndex = 0;
            this.ProdList.Text = "Product List";
            // 
            // btnAddToInvoice
            // 
            this.btnAddToInvoice.BackColor = System.Drawing.Color.SaddleBrown;
            this.btnAddToInvoice.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddToInvoice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddToInvoice.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.btnAddToInvoice.Location = new System.Drawing.Point(615, 168);
            this.btnAddToInvoice.Name = "btnAddToInvoice";
            this.btnAddToInvoice.Size = new System.Drawing.Size(136, 23);
            this.btnAddToInvoice.TabIndex = 6;
            this.btnAddToInvoice.Text = "Add To Invoice";
            this.btnAddToInvoice.UseVisualStyleBackColor = false;
            this.btnAddToInvoice.Click += new System.EventHandler(this.btnAddToInvoice_Click);
            // 
            // txtQuantity
            // 
            this.txtQuantity.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtQuantity.Location = new System.Drawing.Point(615, 133);
            this.txtQuantity.Name = "txtQuantity";
            this.txtQuantity.Size = new System.Drawing.Size(75, 20);
            this.txtQuantity.TabIndex = 5;
            this.txtQuantity.Text = "1";
            // 
            // txtSearch
            // 
            this.txtSearch.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtSearch.Location = new System.Drawing.Point(6, 16);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(225, 20);
            this.txtSearch.TabIndex = 3;
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(565, 76);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(31, 13);
            this.label10.TabIndex = 2;
            this.label10.Text = "Price";
            // 
            // lblPrice
            // 
            this.lblPrice.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice.Location = new System.Drawing.Point(615, 63);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(219, 35);
            this.lblPrice.TabIndex = 2;
            this.lblPrice.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblProductName
            // 
            this.lblProductName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblProductName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProductName.Location = new System.Drawing.Point(615, 10);
            this.lblProductName.Name = "lblProductName";
            this.lblProductName.Size = new System.Drawing.Size(219, 35);
            this.lblProductName.TabIndex = 2;
            this.lblProductName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblProductId
            // 
            this.lblProductId.AutoSize = true;
            this.lblProductId.Location = new System.Drawing.Point(612, 200);
            this.lblProductId.Name = "lblProductId";
            this.lblProductId.Size = new System.Drawing.Size(55, 13);
            this.lblProductId.TabIndex = 2;
            this.lblProductId.Text = "ProductID";
            this.lblProductId.Visible = false;
            // 
            // lblUnitsInStock
            // 
            this.lblUnitsInStock.AutoSize = true;
            this.lblUnitsInStock.Location = new System.Drawing.Point(612, 229);
            this.lblUnitsInStock.Name = "lblUnitsInStock";
            this.lblUnitsInStock.Size = new System.Drawing.Size(68, 13);
            this.lblUnitsInStock.TabIndex = 2;
            this.lblUnitsInStock.Text = "UnitsInStock";
            this.lblUnitsInStock.Visible = false;
            // 
            // lblActualPrice
            // 
            this.lblActualPrice.AutoSize = true;
            this.lblActualPrice.Location = new System.Drawing.Point(712, 200);
            this.lblActualPrice.Name = "lblActualPrice";
            this.lblActualPrice.Size = new System.Drawing.Size(64, 13);
            this.lblActualPrice.TabIndex = 2;
            this.lblActualPrice.Text = "Actual Price";
            this.lblActualPrice.Visible = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(565, 32);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 13);
            this.label8.TabIndex = 2;
            this.label8.Text = "Product";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(565, 136);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 13);
            this.label7.TabIndex = 2;
            this.label7.Text = "Quantity:";
            // 
            // dgProducts
            // 
            this.dgProducts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgProducts.GridColor = System.Drawing.Color.LightSalmon;
            this.dgProducts.Location = new System.Drawing.Point(6, 42);
            this.dgProducts.Name = "dgProducts";
            this.dgProducts.Size = new System.Drawing.Size(540, 174);
            this.dgProducts.TabIndex = 0;
            this.dgProducts.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgProducts_CellClick);
            this.dgProducts.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgProducts_CellContentClick);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Tan;
            this.tabPage2.Controls.Add(this.gpbCustomerInfo);
            this.tabPage2.Controls.Add(this.txtCustomerEmail);
            this.tabPage2.Controls.Add(this.btnSearchCustomer);
            this.tabPage2.Controls.Add(this.dgInvoicing);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(764, 256);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Invoicing";
            // 
            // gpbCustomerInfo
            // 
            this.gpbCustomerInfo.Controls.Add(this.label12);
            this.gpbCustomerInfo.Controls.Add(this.label11);
            this.gpbCustomerInfo.Controls.Add(this.label13);
            this.gpbCustomerInfo.Controls.Add(this.lblCustomerCity);
            this.gpbCustomerInfo.Controls.Add(this.lblCustomerSurname);
            this.gpbCustomerInfo.Controls.Add(this.lblCustomerFirstName);
            this.gpbCustomerInfo.Location = new System.Drawing.Point(24, 48);
            this.gpbCustomerInfo.Name = "gpbCustomerInfo";
            this.gpbCustomerInfo.Size = new System.Drawing.Size(522, 100);
            this.gpbCustomerInfo.TabIndex = 13;
            this.gpbCustomerInfo.TabStop = false;
            this.gpbCustomerInfo.Text = "Customer";
            this.gpbCustomerInfo.Visible = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(270, 37);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(52, 13);
            this.label12.TabIndex = 1;
            this.label12.Text = "Surname:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(22, 37);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(60, 13);
            this.label11.TabIndex = 1;
            this.label11.Text = "First Name:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(55, 67);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(27, 13);
            this.label13.TabIndex = 1;
            this.label13.Text = "City:";
            // 
            // lblCustomerCity
            // 
            this.lblCustomerCity.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCustomerCity.Location = new System.Drawing.Point(88, 57);
            this.lblCustomerCity.Name = "lblCustomerCity";
            this.lblCustomerCity.Size = new System.Drawing.Size(153, 23);
            this.lblCustomerCity.TabIndex = 2;
            // 
            // lblCustomerSurname
            // 
            this.lblCustomerSurname.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCustomerSurname.Location = new System.Drawing.Point(328, 27);
            this.lblCustomerSurname.Name = "lblCustomerSurname";
            this.lblCustomerSurname.Size = new System.Drawing.Size(153, 23);
            this.lblCustomerSurname.TabIndex = 2;
            // 
            // lblCustomerFirstName
            // 
            this.lblCustomerFirstName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCustomerFirstName.Location = new System.Drawing.Point(88, 27);
            this.lblCustomerFirstName.Name = "lblCustomerFirstName";
            this.lblCustomerFirstName.Size = new System.Drawing.Size(153, 23);
            this.lblCustomerFirstName.TabIndex = 2;
            // 
            // txtCustomerEmail
            // 
            this.txtCustomerEmail.Location = new System.Drawing.Point(161, 18);
            this.txtCustomerEmail.Name = "txtCustomerEmail";
            this.txtCustomerEmail.Size = new System.Drawing.Size(178, 20);
            this.txtCustomerEmail.TabIndex = 2;
            // 
            // btnSearchCustomer
            // 
            this.btnSearchCustomer.BackColor = System.Drawing.Color.SaddleBrown;
            this.btnSearchCustomer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearchCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearchCustomer.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.btnSearchCustomer.Location = new System.Drawing.Point(345, 11);
            this.btnSearchCustomer.Name = "btnSearchCustomer";
            this.btnSearchCustomer.Size = new System.Drawing.Size(134, 31);
            this.btnSearchCustomer.TabIndex = 12;
            this.btnSearchCustomer.Text = "Search";
            this.btnSearchCustomer.UseVisualStyleBackColor = false;
            this.btnSearchCustomer.Click += new System.EventHandler(this.btnSearchCustomer_Click);
            // 
            // dgInvoicing
            // 
            this.dgInvoicing.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgInvoicing.GridColor = System.Drawing.Color.LightSalmon;
            this.dgInvoicing.Location = new System.Drawing.Point(6, 154);
            this.dgInvoicing.Name = "dgInvoicing";
            this.dgInvoicing.Size = new System.Drawing.Size(743, 96);
            this.dgInvoicing.TabIndex = 1;
            this.dgInvoicing.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgInvoicing_CellContentClick);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(21, 25);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(134, 13);
            this.label9.TabIndex = 1;
            this.label9.Text = "Search Customer By Email:";
            // 
            // orderBindingSource
            // 
            this.orderBindingSource.DataMember = "Order";
            this.orderBindingSource.DataSource = this.dataSet1;
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "DataSet1";
            this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // orderTableAdapter
            // 
            this.orderTableAdapter.ClearBeforeFill = true;
            // 
            // orderLineBindingSource
            // 
            this.orderLineBindingSource.DataMember = "OrderLine";
            this.orderLineBindingSource.DataSource = this.dataSet1;
            // 
            // orderLineTableAdapter
            // 
            this.orderLineTableAdapter.ClearBeforeFill = true;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.SaddleBrown;
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button1.Location = new System.Drawing.Point(961, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(40, 30);
            this.button1.TabIndex = 6;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1023, 519);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.ProdList.ResumeLayout(false);
            this.ProdList.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgProducts)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.gpbCustomerInfo.ResumeLayout(false);
            this.gpbCustomerInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgInvoicing)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderLineBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox lblChange;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox Cost;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button NewCustomer;
        private System.Windows.Forms.Button Pay;
        private System.Windows.Forms.Button Remove;
        private System.Windows.Forms.Button Print;
        private System.Windows.Forms.Button Reset;
        private System.Windows.Forms.Button Availability;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage ProdList;
        private System.Windows.Forms.Button btnAddToInvoice;
        private System.Windows.Forms.TextBox txtQuantity;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView dgProducts;
        private System.Windows.Forms.TabPage tabPage2;
        private EventHandler SearchBtn_Click;
        private DataSet1 dataSet1;
        private System.Windows.Forms.BindingSource orderBindingSource;
        private DataSet1TableAdapters.OrderTableAdapter orderTableAdapter;
        private System.Windows.Forms.BindingSource orderLineBindingSource;
        private DataSet1TableAdapters.OrderLineTableAdapter orderLineTableAdapter;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblProductName;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblUnitsInStock;
        private System.Windows.Forms.Label lblActualPrice;
        private System.Windows.Forms.Label lblProductId;
        private System.Windows.Forms.DataGridView dgInvoicing;
        private System.Windows.Forms.Label lblSubTotalInvoicePrice;
        private System.Windows.Forms.Label lblTotalInvoicePrice;
        private System.Windows.Forms.Label lblVat;
        private System.Windows.Forms.GroupBox gpbCustomerInfo;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblCustomerCity;
        private System.Windows.Forms.Label lblCustomerSurname;
        private System.Windows.Forms.Label lblCustomerFirstName;
        private System.Windows.Forms.TextBox txtCustomerEmail;
        private System.Windows.Forms.Button btnSearchCustomer;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button1;

        public EventHandler cmbPayMethod_SelectedIndexChanged { get; private set; }
    }
}