﻿namespace POS_Project
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label customerIDLabel;
            System.Windows.Forms.Label first_NameLabel;
            System.Windows.Forms.Label last_NameLabel;
            System.Windows.Forms.Label email_AddressLabel;
            System.Windows.Forms.Label genderLabel;
            System.Windows.Forms.Label contact_NumberLabel;
            System.Windows.Forms.Label date_Of_BirthLabel;
            System.Windows.Forms.Label city_NameLabel;
            System.Windows.Forms.Label cityl_CodeLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.customerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet1 = new POS_Project.DataSet1();
            this.panel2 = new System.Windows.Forms.Panel();
            this.customerIDTextBox = new System.Windows.Forms.TextBox();
            this.customerBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.customerDataSet = new POS_Project.CustomerDataSet();
            this.first_NameTextBox = new System.Windows.Forms.TextBox();
            this.last_NameTextBox = new System.Windows.Forms.TextBox();
            this.email_AddressTextBox = new System.Windows.Forms.TextBox();
            this.genderTextBox = new System.Windows.Forms.TextBox();
            this.contact_NumberTextBox = new System.Windows.Forms.TextBox();
            this.date_Of_BirthDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.city_NameTextBox = new System.Windows.Forms.TextBox();
            this.cityl_CodeTextBox = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.customerTableAdapter = new POS_Project.DataSet1TableAdapters.CustomerTableAdapter();
            this.customerDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.searchCustomerToolStrip = new System.Windows.Forms.ToolStrip();
            this.first_NameToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.first_NameToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.searchCustomerToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.customerTableAdapter1 = new POS_Project.CustomerDataSetTableAdapters.CustomerTableAdapter();
            this.tableAdapterManager = new POS_Project.CustomerDataSetTableAdapters.TableAdapterManager();
            this.button5 = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            customerIDLabel = new System.Windows.Forms.Label();
            first_NameLabel = new System.Windows.Forms.Label();
            last_NameLabel = new System.Windows.Forms.Label();
            email_AddressLabel = new System.Windows.Forms.Label();
            genderLabel = new System.Windows.Forms.Label();
            contact_NumberLabel = new System.Windows.Forms.Label();
            date_Of_BirthLabel = new System.Windows.Forms.Label();
            city_NameLabel = new System.Windows.Forms.Label();
            cityl_CodeLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerDataGridView)).BeginInit();
            this.searchCustomerToolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // customerIDLabel
            // 
            customerIDLabel.AutoSize = true;
            customerIDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            customerIDLabel.Location = new System.Drawing.Point(10, 23);
            customerIDLabel.Name = "customerIDLabel";
            customerIDLabel.Size = new System.Drawing.Size(78, 15);
            customerIDLabel.TabIndex = 21;
            customerIDLabel.Text = "Customer ID:";
            // 
            // first_NameLabel
            // 
            first_NameLabel.AutoSize = true;
            first_NameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            first_NameLabel.Location = new System.Drawing.Point(10, 60);
            first_NameLabel.Name = "first_NameLabel";
            first_NameLabel.Size = new System.Drawing.Size(70, 15);
            first_NameLabel.TabIndex = 23;
            first_NameLabel.Text = "First Name:";
            // 
            // last_NameLabel
            // 
            last_NameLabel.AutoSize = true;
            last_NameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            last_NameLabel.Location = new System.Drawing.Point(10, 105);
            last_NameLabel.Name = "last_NameLabel";
            last_NameLabel.Size = new System.Drawing.Size(70, 15);
            last_NameLabel.TabIndex = 25;
            last_NameLabel.Text = "Last Name:";
            // 
            // email_AddressLabel
            // 
            email_AddressLabel.AutoSize = true;
            email_AddressLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            email_AddressLabel.Location = new System.Drawing.Point(10, 150);
            email_AddressLabel.Name = "email_AddressLabel";
            email_AddressLabel.Size = new System.Drawing.Size(89, 15);
            email_AddressLabel.TabIndex = 27;
            email_AddressLabel.Text = "Email Address:";
            // 
            // genderLabel
            // 
            genderLabel.AutoSize = true;
            genderLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            genderLabel.Location = new System.Drawing.Point(10, 188);
            genderLabel.Name = "genderLabel";
            genderLabel.Size = new System.Drawing.Size(51, 15);
            genderLabel.TabIndex = 29;
            genderLabel.Text = "Gender:";
            // 
            // contact_NumberLabel
            // 
            contact_NumberLabel.AutoSize = true;
            contact_NumberLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            contact_NumberLabel.Location = new System.Drawing.Point(10, 224);
            contact_NumberLabel.Name = "contact_NumberLabel";
            contact_NumberLabel.Size = new System.Drawing.Size(99, 15);
            contact_NumberLabel.TabIndex = 31;
            contact_NumberLabel.Text = "Contact Number:";
            // 
            // date_Of_BirthLabel
            // 
            date_Of_BirthLabel.AutoSize = true;
            date_Of_BirthLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            date_Of_BirthLabel.Location = new System.Drawing.Point(10, 263);
            date_Of_BirthLabel.Name = "date_Of_BirthLabel";
            date_Of_BirthLabel.Size = new System.Drawing.Size(79, 15);
            date_Of_BirthLabel.TabIndex = 33;
            date_Of_BirthLabel.Text = "Date Of Birth:";
            // 
            // city_NameLabel
            // 
            city_NameLabel.AutoSize = true;
            city_NameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            city_NameLabel.Location = new System.Drawing.Point(10, 300);
            city_NameLabel.Name = "city_NameLabel";
            city_NameLabel.Size = new System.Drawing.Size(66, 15);
            city_NameLabel.TabIndex = 35;
            city_NameLabel.Text = "City Name:";
            // 
            // cityl_CodeLabel
            // 
            cityl_CodeLabel.AutoSize = true;
            cityl_CodeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            cityl_CodeLabel.Location = new System.Drawing.Point(12, 336);
            cityl_CodeLabel.Name = "cityl_CodeLabel";
            cityl_CodeLabel.Size = new System.Drawing.Size(64, 15);
            cityl_CodeLabel.TabIndex = 37;
            cityl_CodeLabel.Text = "Cityl Code:";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.SaddleBrown;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.button1.Location = new System.Drawing.Point(304, 98);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 17;
            this.button1.Text = "Search";
            this.toolTip1.SetToolTip(this.button1, "Search by name");
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.AntiqueWhite;
            this.textBox1.Location = new System.Drawing.Point(385, 100);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(142, 20);
            this.textBox1.TabIndex = 16;
            // 
            // customerBindingSource
            // 
            this.customerBindingSource.DataMember = "Customer";
            this.customerBindingSource.DataSource = this.dataSet1;
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "DataSet1";
            this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Tan;
            this.panel2.Controls.Add(customerIDLabel);
            this.panel2.Controls.Add(this.customerIDTextBox);
            this.panel2.Controls.Add(first_NameLabel);
            this.panel2.Controls.Add(this.first_NameTextBox);
            this.panel2.Controls.Add(last_NameLabel);
            this.panel2.Controls.Add(this.last_NameTextBox);
            this.panel2.Controls.Add(email_AddressLabel);
            this.panel2.Controls.Add(this.email_AddressTextBox);
            this.panel2.Controls.Add(genderLabel);
            this.panel2.Controls.Add(this.genderTextBox);
            this.panel2.Controls.Add(contact_NumberLabel);
            this.panel2.Controls.Add(this.contact_NumberTextBox);
            this.panel2.Controls.Add(date_Of_BirthLabel);
            this.panel2.Controls.Add(this.date_Of_BirthDateTimePicker);
            this.panel2.Controls.Add(city_NameLabel);
            this.panel2.Controls.Add(this.city_NameTextBox);
            this.panel2.Controls.Add(cityl_CodeLabel);
            this.panel2.Controls.Add(this.cityl_CodeTextBox);
            this.panel2.Controls.Add(this.button4);
            this.panel2.Controls.Add(this.button3);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Location = new System.Drawing.Point(2, 52);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(275, 426);
            this.panel2.TabIndex = 13;
            // 
            // customerIDTextBox
            // 
            this.customerIDTextBox.BackColor = System.Drawing.Color.AntiqueWhite;
            this.customerIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource1, "CustomerID", true));
            this.customerIDTextBox.Location = new System.Drawing.Point(113, 20);
            this.customerIDTextBox.Name = "customerIDTextBox";
            this.customerIDTextBox.Size = new System.Drawing.Size(130, 20);
            this.customerIDTextBox.TabIndex = 22;
            // 
            // customerBindingSource1
            // 
            this.customerBindingSource1.DataMember = "Customer";
            this.customerBindingSource1.DataSource = this.customerDataSet;
            // 
            // customerDataSet
            // 
            this.customerDataSet.DataSetName = "CustomerDataSet";
            this.customerDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // first_NameTextBox
            // 
            this.first_NameTextBox.BackColor = System.Drawing.Color.AntiqueWhite;
            this.first_NameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource1, "First_Name", true));
            this.first_NameTextBox.Location = new System.Drawing.Point(113, 57);
            this.first_NameTextBox.Name = "first_NameTextBox";
            this.first_NameTextBox.Size = new System.Drawing.Size(130, 20);
            this.first_NameTextBox.TabIndex = 24;
            // 
            // last_NameTextBox
            // 
            this.last_NameTextBox.BackColor = System.Drawing.Color.AntiqueWhite;
            this.last_NameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource1, "Last_Name", true));
            this.last_NameTextBox.Location = new System.Drawing.Point(113, 102);
            this.last_NameTextBox.Name = "last_NameTextBox";
            this.last_NameTextBox.Size = new System.Drawing.Size(130, 20);
            this.last_NameTextBox.TabIndex = 26;
            // 
            // email_AddressTextBox
            // 
            this.email_AddressTextBox.BackColor = System.Drawing.Color.AntiqueWhite;
            this.email_AddressTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource1, "Email_Address", true));
            this.email_AddressTextBox.Location = new System.Drawing.Point(113, 147);
            this.email_AddressTextBox.Name = "email_AddressTextBox";
            this.email_AddressTextBox.Size = new System.Drawing.Size(130, 20);
            this.email_AddressTextBox.TabIndex = 28;
            // 
            // genderTextBox
            // 
            this.genderTextBox.BackColor = System.Drawing.Color.AntiqueWhite;
            this.genderTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource1, "Gender", true));
            this.genderTextBox.Location = new System.Drawing.Point(113, 185);
            this.genderTextBox.Name = "genderTextBox";
            this.genderTextBox.Size = new System.Drawing.Size(130, 20);
            this.genderTextBox.TabIndex = 30;
            // 
            // contact_NumberTextBox
            // 
            this.contact_NumberTextBox.BackColor = System.Drawing.Color.AntiqueWhite;
            this.contact_NumberTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource1, "Contact_Number", true));
            this.contact_NumberTextBox.Location = new System.Drawing.Point(113, 221);
            this.contact_NumberTextBox.Name = "contact_NumberTextBox";
            this.contact_NumberTextBox.Size = new System.Drawing.Size(130, 20);
            this.contact_NumberTextBox.TabIndex = 32;
            // 
            // date_Of_BirthDateTimePicker
            // 
            this.date_Of_BirthDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.customerBindingSource1, "Date_Of_Birth", true));
            this.date_Of_BirthDateTimePicker.Location = new System.Drawing.Point(113, 259);
            this.date_Of_BirthDateTimePicker.Name = "date_Of_BirthDateTimePicker";
            this.date_Of_BirthDateTimePicker.Size = new System.Drawing.Size(130, 20);
            this.date_Of_BirthDateTimePicker.TabIndex = 34;
            // 
            // city_NameTextBox
            // 
            this.city_NameTextBox.BackColor = System.Drawing.Color.AntiqueWhite;
            this.city_NameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource1, "City_Name", true));
            this.city_NameTextBox.Location = new System.Drawing.Point(113, 297);
            this.city_NameTextBox.Name = "city_NameTextBox";
            this.city_NameTextBox.Size = new System.Drawing.Size(130, 20);
            this.city_NameTextBox.TabIndex = 36;
            // 
            // cityl_CodeTextBox
            // 
            this.cityl_CodeTextBox.BackColor = System.Drawing.Color.AntiqueWhite;
            this.cityl_CodeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource1, "Cityl_Code", true));
            this.cityl_CodeTextBox.Location = new System.Drawing.Point(115, 333);
            this.cityl_CodeTextBox.Name = "cityl_CodeTextBox";
            this.cityl_CodeTextBox.Size = new System.Drawing.Size(130, 20);
            this.cityl_CodeTextBox.TabIndex = 38;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.SaddleBrown;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.button4.Location = new System.Drawing.Point(191, 376);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(81, 30);
            this.button4.TabIndex = 21;
            this.button4.Text = "Remove";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.SaddleBrown;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.button3.Location = new System.Drawing.Point(100, 376);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(85, 30);
            this.button3.TabIndex = 20;
            this.button3.Text = "Save";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.SaddleBrown;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.button2.Location = new System.Drawing.Point(10, 376);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(84, 30);
            this.button2.TabIndex = 12;
            this.button2.Text = "Add New";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Tan;
            this.label1.Font = new System.Drawing.Font("Sitka Subheading", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(331, -4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(321, 42);
            this.label1.TabIndex = 18;
            this.label1.Text = "Customer Information";
            // 
            // customerTableAdapter
            // 
            this.customerTableAdapter.ClearBeforeFill = true;
            // 
            // customerDataGridView
            // 
            this.customerDataGridView.AutoGenerateColumns = false;
            this.customerDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.customerDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9});
            this.customerDataGridView.DataSource = this.customerBindingSource1;
            this.customerDataGridView.Location = new System.Drawing.Point(283, 124);
            this.customerDataGridView.Name = "customerDataGridView";
            this.customerDataGridView.Size = new System.Drawing.Size(742, 334);
            this.customerDataGridView.TabIndex = 18;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "CustomerID";
            this.dataGridViewTextBoxColumn1.HeaderText = "CustomerID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "First_Name";
            this.dataGridViewTextBoxColumn2.HeaderText = "First_Name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Last_Name";
            this.dataGridViewTextBoxColumn3.HeaderText = "Last_Name";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Email_Address";
            this.dataGridViewTextBoxColumn4.HeaderText = "Email_Address";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Gender";
            this.dataGridViewTextBoxColumn5.HeaderText = "Gender";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Contact_Number";
            this.dataGridViewTextBoxColumn6.HeaderText = "Contact_Number";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Date_Of_Birth";
            this.dataGridViewTextBoxColumn7.HeaderText = "Date_Of_Birth";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "City_Name";
            this.dataGridViewTextBoxColumn8.HeaderText = "City_Name";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Cityl_Code";
            this.dataGridViewTextBoxColumn9.HeaderText = "Cityl_Code";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // searchCustomerToolStrip
            // 
            this.searchCustomerToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.first_NameToolStripLabel,
            this.first_NameToolStripTextBox,
            this.searchCustomerToolStripButton});
            this.searchCustomerToolStrip.Location = new System.Drawing.Point(0, 0);
            this.searchCustomerToolStrip.Name = "searchCustomerToolStrip";
            this.searchCustomerToolStrip.Size = new System.Drawing.Size(1050, 25);
            this.searchCustomerToolStrip.TabIndex = 19;
            this.searchCustomerToolStrip.Text = "searchCustomerToolStrip";
            this.searchCustomerToolStrip.Visible = false;
            this.searchCustomerToolStrip.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.searchCustomerToolStrip_ItemClicked);
            // 
            // first_NameToolStripLabel
            // 
            this.first_NameToolStripLabel.Name = "first_NameToolStripLabel";
            this.first_NameToolStripLabel.Size = new System.Drawing.Size(69, 22);
            this.first_NameToolStripLabel.Text = "First_Name:";
            // 
            // first_NameToolStripTextBox
            // 
            this.first_NameToolStripTextBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.first_NameToolStripTextBox.Name = "first_NameToolStripTextBox";
            this.first_NameToolStripTextBox.Size = new System.Drawing.Size(100, 25);
            // 
            // searchCustomerToolStripButton
            // 
            this.searchCustomerToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.searchCustomerToolStripButton.Name = "searchCustomerToolStripButton";
            this.searchCustomerToolStripButton.Size = new System.Drawing.Size(98, 22);
            this.searchCustomerToolStripButton.Text = "SearchCustomer";
            this.searchCustomerToolStripButton.Click += new System.EventHandler(this.searchCustomerToolStripButton_Click);
            // 
            // customerTableAdapter1
            // 
            this.customerTableAdapter1.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CustomerTableAdapter = this.customerTableAdapter1;
            this.tableAdapterManager.UpdateOrder = POS_Project.CustomerDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.SaddleBrown;
            this.button5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button5.BackgroundImage")));
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button5.Location = new System.Drawing.Point(985, 8);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(40, 30);
            this.button5.TabIndex = 20;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1050, 25);
            this.toolStrip1.TabIndex = 21;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AntiqueWhite;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1050, 498);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.searchCustomerToolStrip);
            this.Controls.Add(this.customerDataGridView);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.panel2);
            this.Name = "Form4";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form4";
            this.Load += new System.EventHandler(this.Form4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerDataGridView)).EndInit();
            this.searchCustomerToolStrip.ResumeLayout(false);
            this.searchCustomerToolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label1;
        private DataSet1 dataSet1;
        private System.Windows.Forms.BindingSource customerBindingSource;
        private DataSet1TableAdapters.CustomerTableAdapter customerTableAdapter;
        private CustomerDataSet customerDataSet;
        private System.Windows.Forms.BindingSource customerBindingSource1;
        private CustomerDataSetTableAdapters.CustomerTableAdapter customerTableAdapter1;
        private CustomerDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TextBox customerIDTextBox;
        private System.Windows.Forms.TextBox first_NameTextBox;
        private System.Windows.Forms.TextBox last_NameTextBox;
        private System.Windows.Forms.TextBox email_AddressTextBox;
        private System.Windows.Forms.TextBox genderTextBox;
        private System.Windows.Forms.TextBox contact_NumberTextBox;
        private System.Windows.Forms.DateTimePicker date_Of_BirthDateTimePicker;
        private System.Windows.Forms.TextBox city_NameTextBox;
        private System.Windows.Forms.TextBox cityl_CodeTextBox;
        private System.Windows.Forms.DataGridView customerDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.ToolStrip searchCustomerToolStrip;
        private System.Windows.Forms.ToolStripLabel first_NameToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox first_NameToolStripTextBox;
        private System.Windows.Forms.ToolStripButton searchCustomerToolStripButton;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ToolStrip toolStrip1;
    }
}