﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS_Project
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'supplierDataSet.Supplier' table. You can move, or remove it, as needed.
            this.supplierTableAdapter1.Fill(this.supplierDataSet.Supplier);
            // TODO: This line of code loads data into the 'dataSet1.Supplier' table. You can move, or remove it, as needed.
            this.supplierTableAdapter.Fill(this.dataSet1.Supplier);

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.supplierBindingSource1.AddNew();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.supplierBindingSource1.EndEdit();
            this.tableAdapterManager.UpdateAll(this.supplierDataSet);
            MessageBox.Show("Supplier successfully added");
        }

        private void searchSupplierToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.supplierTableAdapter1.SearchSupplier(this.supplierDataSet.Supplier, supplier_TypeToolStripTextBox.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                this.supplierTableAdapter1.SearchSupplier(this.supplierDataSet.Supplier, textBox1.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form2 Homepage = new Form2();
            Homepage.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.supplierBindingSource1.RemoveCurrent();
        }
    }
}
