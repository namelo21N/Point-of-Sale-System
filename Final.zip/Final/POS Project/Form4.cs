﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace POS_Project
{
    public partial class Form4 : Form
    {
        private readonly string _ConnectionString;

        public Form4()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.customerBindingSource1.AddNew();

        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'customerDataSet.Customer' table. You can move, or remove it, as needed.
            this.customerTableAdapter1.Fill(this.customerDataSet.Customer);
            // TODO: This line of code loads data into the 'dataSet1.Customer' table. You can move, or remove it, as needed.
            this.customerTableAdapter.Fill(this.dataSet1.Customer);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.customerBindingSource1.EndEdit();
            this.tableAdapterManager.UpdateAll(this.customerDataSet);
            MessageBox.Show("Customer successfully saved");
        }

        private void searchCustomerToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.customerTableAdapter1.SearchCustomer(this.customerDataSet.Customer, first_NameToolStripTextBox.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void searchCustomerToolStrip_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                this.customerTableAdapter1.SearchCustomer(this.customerDataSet.Customer, textBox1.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form2 Homepage = new Form2();
            Homepage.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.customerBindingSource1.RemoveCurrent();
        }
    }
}
