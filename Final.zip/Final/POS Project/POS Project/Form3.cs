﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace POS_Project
{
    public partial class Form3 : Form
    {
        private readonly List<Product> _products;
        private  Product _selectedProduct;

        public Form3()
        {
            InitializeComponent();
            _products = new List<Product>();

        }
        DataTable dt = new DataTable("Orderline");
        SqlConnection con = new SqlConnection("Data Source=146.230.177.46;Persist Security Info=True;User ID=GroupWst8;Password=47syh");


        private void SearchProducts()
        {
            try
            {
                using (SqlConnection cn = new SqlConnection("Data Source=146.230.177.46;Persist Security Info=True;User ID=GroupWst8;Password=47syh"))
                {
                    if (cn.State == ConnectionState.Closed)
                        cn.Open();
                    using (DataTable dt = new DataTable("OrderLine"))
                    {
                        using (SqlCommand cmd = new SqlCommand("Select * from OrderLine where Name like " + txtSearch.Text))
                        {
                            cmd.Parameters.AddWithValue("Name", string.Format("%{0}%", txtSearch.Text));
                            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                            adapter.Fill(dt);
                            dgProducts.DataSource = dt;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }




        private void NewCustomer_Click(object sender, EventArgs e)
        {
            new Form4().Show();
            this.Hide();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            //// TODO: This line of code loads data into the 'dataSet1.OrderLine' table. You can move, or remove it, as needed.
            //this.orderLineTableAdapter.Fill(this.dataSet1.OrderLine);
            //// TODO: This line of code loads data into the 'dataSet1.Order' table. You can move, or remove it, as needed.
            //this.orderTableAdapter.Fill(this.dataSet1.Order);
            BindProducts();
            AddSelectButton();
        }

        private void SearchBtn_Click_1(object sender, EventArgs e)
        {


        }

        private void BindProducts()
        {
            if (txtSearch.TextLength > 0 && txtSearch.TextLength < 3) return;
            string product = txtSearch.Text;
            var data = new Data();
            List<Product> products = data.Search(product);
            dgProducts.DataSource = products;
            dgProducts.Columns[0].Visible = false;
            dgProducts.Columns[4].Visible = false;
        }
        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            BindProducts();
            AddSelectButton();

        }
        private void AddSelectButton()
        {
            var btnSelectProduct = new DataGridViewButtonColumn();
            btnSelectProduct.Name = String.Empty;
            btnSelectProduct.Text = "Select";
            btnSelectProduct.UseColumnTextForButtonValue = true;
            dgProducts.Columns.Add(btnSelectProduct);
        }

        private void dgProducts_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgProducts_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex != dgProducts.ColumnCount - 1) return;
            int productId = (int)dgProducts[0, e.RowIndex].Value;
            int numberOfUnitsInStock = (int)dgProducts[3, e.RowIndex].Value;            
            string productName = (string)dgProducts[1, e.RowIndex].Value;
            decimal price = (decimal)dgProducts[2, e.RowIndex].Value;
            lblPrice.Text = price.ToString();
            lblActualPrice.Text = price.ToString();
            lblProductName.Text = productName;
            lblProductId.Text = productId.ToString();
            _selectedProduct = new Product
            {
                ProductId = productId,
                ProductName = productName,
                Price =  price,
                NumberOfItemsInStock = numberOfUnitsInStock
            };
            
        }

        private void btnAddToInvoice_Click(object sender, EventArgs e)
        {
            if (_selectedProduct == null) return;
            decimal.TryParse(lblActualPrice.Text, out decimal unitPrice);
            int.TryParse(lblUnitsInStock.Text, out int numberOfUnitsInStock);
            int.TryParse(txtQuantity.Text, out int quantity);
            int.TryParse(lblProductId.Text, out int productId);
            string productName = lblProductName.Text;
            _selectedProduct.Quantity = quantity;
            _selectedProduct.Price = _selectedProduct.Price * _selectedProduct.Quantity;
            _products.Add(_selectedProduct);
            SetInvoicingData(_products);
            ClearProductSelection();
        }

        private void ClearProductSelection()
        {
            txtQuantity.Text = String.Empty;
            lblActualPrice.Text = String.Empty;
            lblPrice.Text = String.Empty;
            lblProductId.Text = string.Empty;
            lblProductName.Text = string.Empty;
            lblUnitsInStock.Text = string.Empty;
        }
        private void SetInvoicingData(List<Product> products)
        {
            dgInvoicing.Refresh();
            dgInvoicing.DataSource = products;            
            dgInvoicing.Columns[0].Visible = false;
            dgInvoicing.Columns[3].Visible = false;
            lblSubTotalInvoicePrice.Text = products.Sum(p => p.Price).ToString();
            lblVat.Text = (products.Sum(p => p.Price) * 0.15M).ToString();
            decimal.TryParse(lblSubTotalInvoicePrice.Text, out decimal subTotal);
            decimal.TryParse(lblVat.Text, out decimal vat);
            lblTotalInvoicePrice.Text =  ( subTotal + vat).ToString();
        }
    }


}

