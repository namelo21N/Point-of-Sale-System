﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace POS_Project
{
    internal class Data
    {
        private readonly string _ConnectionString;
        public Data()
        {
            _ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["processSaleConnectionString"].ConnectionString;

        }

        internal List<Product> Search(string productName)
        {
            var products = new List<Product>();
            using (SqlConnection cn = new SqlConnection(_ConnectionString))
            {
                cn.Open();
                
                    using (SqlCommand cmd = new SqlCommand(@"Select [ProductID]      
      ,[Name]
      ,[Selling_Price]
      ,[Unit_In_Stock]      
       from [GroupWst8].[dbo].[Product] where Name like '%' + @Name + '%'", cn))
                    {
                        cmd.Parameters.AddWithValue("@Name", productName);
                        SqlDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            var product = new Product
                            {
                                ProductId = (int)reader["ProductID"],
                                ProductName = (string)reader["Name"],
                                Price = (decimal)reader["Selling_Price"],
                                NumberOfItemsInStock = (int)reader["Unit_In_Stock"]
                            };
                            products.Add(product);
                        }
                    reader.Close();
                        cn.Close();
                        return products;
                    }
               
            }
        }

    }
}
