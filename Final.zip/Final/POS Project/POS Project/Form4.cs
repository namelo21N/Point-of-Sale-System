﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace POS_Project
{
    public partial class Form4 : Form
    {
        private readonly string _ConnectionString;

        public Form4()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

            using (SqlConnection sql = new SqlConnection( _ConnectionString))
            {
                sql.Open();
                SqlCommand cmd = new SqlCommand($"Select * from Customer where CustomerID = @CustomerID", sql);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("CustomerID", textBox2.Text);
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    textBox3.Text = $"Name: {rdr["First_Name"].ToString()}";
                    textBox4.Text = $"Surname: {rdr["Last_Name"].ToString()}";
                    textBox5.Text = $"Email Address: {rdr["Email_Address"].ToString()}";
                    textBox6.Text = $"Gender: {rdr["Gender"].ToString()}";
                    textBox7.Text = $"Contact: {rdr["Contact_Number"].ToString()}";
                    textBox8.Text = $"Date Of Birth: {rdr["Date_Of_Birth"].ToString()}";
                    textBox9.Text = $"City: {rdr["City_Name"].ToString()}";
                    textBox10.Text = $"City Code: {rdr["Cityl_Code"].ToString()}";


                }
            }

        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSet1.Customer' table. You can move, or remove it, as needed.
            this.customerTableAdapter.Fill(this.dataSet1.Customer);

        }
    }
}
