﻿using System;

namespace POS_Project
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.panel6 = new System.Windows.Forms.Panel();
            this.cmbPayMethod = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.lblChange = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Cost = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.NewCustomer = new System.Windows.Forms.Button();
            this.Pay = new System.Windows.Forms.Button();
            this.Remove = new System.Windows.Forms.Button();
            this.Print = new System.Windows.Forms.Button();
            this.Reset = new System.Windows.Forms.Button();
            this.Availability = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.ProdList = new System.Windows.Forms.TabPage();
            this.btnAddToInvoice = new System.Windows.Forms.Button();
            this.txtQuantity = new System.Windows.Forms.TextBox();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblProductName = new System.Windows.Forms.Label();
            this.lblProductId = new System.Windows.Forms.Label();
            this.lblUnitsInStock = new System.Windows.Forms.Label();
            this.lblActualPrice = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.dgProducts = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.orderBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet1 = new POS_Project.DataSet1();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btnDot = new System.Windows.Forms.Button();
            this.btn0 = new System.Windows.Forms.Button();
            this.btnC = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.orderTableAdapter = new POS_Project.DataSet1TableAdapters.OrderTableAdapter();
            this.orderLineBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.orderLineTableAdapter = new POS_Project.DataSet1TableAdapters.OrderLineTableAdapter();
            this.dgInvoicing = new System.Windows.Forms.DataGridView();
            this.lblSubTotalInvoicePrice = new System.Windows.Forms.Label();
            this.lblVat = new System.Windows.Forms.Label();
            this.lblTotalInvoicePrice = new System.Windows.Forms.Label();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.ProdList.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgProducts)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.orderBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.orderLineBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgInvoicing)).BeginInit();
            this.SuspendLayout();
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Tan;
            this.panel6.Controls.Add(this.cmbPayMethod);
            this.panel6.Controls.Add(this.label5);
            this.panel6.Controls.Add(this.lblChange);
            this.panel6.Controls.Add(this.label6);
            this.panel6.Controls.Add(this.Cost);
            this.panel6.Controls.Add(this.label4);
            this.panel6.Location = new System.Drawing.Point(303, 306);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(344, 201);
            this.panel6.TabIndex = 11;
            // 
            // cmbPayMethod
            // 
            this.cmbPayMethod.BackColor = System.Drawing.Color.WhiteSmoke;
            this.cmbPayMethod.FormattingEnabled = true;
            this.cmbPayMethod.Location = new System.Drawing.Point(143, 12);
            this.cmbPayMethod.Name = "cmbPayMethod";
            this.cmbPayMethod.Size = new System.Drawing.Size(121, 21);
            this.cmbPayMethod.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 130);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Change";
            // 
            // lblChange
            // 
            this.lblChange.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lblChange.Location = new System.Drawing.Point(143, 123);
            this.lblChange.Name = "lblChange";
            this.lblChange.Size = new System.Drawing.Size(121, 20);
            this.lblChange.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 75);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(28, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Cost";
            // 
            // Cost
            // 
            this.Cost.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Cost.Location = new System.Drawing.Point(143, 68);
            this.Cost.Name = "Cost";
            this.Cost.Size = new System.Drawing.Size(121, 20);
            this.Cost.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 15);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Payment Method";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Tan;
            this.panel5.Controls.Add(this.NewCustomer);
            this.panel5.Controls.Add(this.Pay);
            this.panel5.Controls.Add(this.Remove);
            this.panel5.Controls.Add(this.Print);
            this.panel5.Controls.Add(this.Reset);
            this.panel5.Controls.Add(this.Availability);
            this.panel5.Location = new System.Drawing.Point(653, 307);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(367, 200);
            this.panel5.TabIndex = 10;
            // 
            // NewCustomer
            // 
            this.NewCustomer.BackColor = System.Drawing.Color.SaddleBrown;
            this.NewCustomer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NewCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewCustomer.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.NewCustomer.Location = new System.Drawing.Point(183, 139);
            this.NewCustomer.Name = "NewCustomer";
            this.NewCustomer.Size = new System.Drawing.Size(169, 47);
            this.NewCustomer.TabIndex = 17;
            this.NewCustomer.Text = "New Customer";
            this.NewCustomer.UseVisualStyleBackColor = false;
            // 
            // Pay
            // 
            this.Pay.BackColor = System.Drawing.Color.SaddleBrown;
            this.Pay.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Pay.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pay.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.Pay.Location = new System.Drawing.Point(3, 3);
            this.Pay.Name = "Pay";
            this.Pay.Size = new System.Drawing.Size(169, 47);
            this.Pay.TabIndex = 12;
            this.Pay.Text = "Pay";
            this.Pay.UseVisualStyleBackColor = false;
            // 
            // Remove
            // 
            this.Remove.BackColor = System.Drawing.Color.SaddleBrown;
            this.Remove.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Remove.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Remove.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.Remove.Location = new System.Drawing.Point(3, 71);
            this.Remove.Name = "Remove";
            this.Remove.Size = new System.Drawing.Size(169, 47);
            this.Remove.TabIndex = 14;
            this.Remove.Text = "Remove";
            this.Remove.UseVisualStyleBackColor = false;
            // 
            // Print
            // 
            this.Print.BackColor = System.Drawing.Color.SaddleBrown;
            this.Print.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Print.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Print.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.Print.Location = new System.Drawing.Point(3, 139);
            this.Print.Name = "Print";
            this.Print.Size = new System.Drawing.Size(169, 47);
            this.Print.TabIndex = 16;
            this.Print.Text = "Print";
            this.Print.UseVisualStyleBackColor = false;
            // 
            // Reset
            // 
            this.Reset.BackColor = System.Drawing.Color.SaddleBrown;
            this.Reset.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Reset.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.Reset.Location = new System.Drawing.Point(183, 0);
            this.Reset.Name = "Reset";
            this.Reset.Size = new System.Drawing.Size(169, 47);
            this.Reset.TabIndex = 13;
            this.Reset.Text = "Reset";
            this.Reset.UseVisualStyleBackColor = false;
            // 
            // Availability
            // 
            this.Availability.BackColor = System.Drawing.Color.SaddleBrown;
            this.Availability.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Availability.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Availability.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.Availability.Location = new System.Drawing.Point(183, 71);
            this.Availability.Name = "Availability";
            this.Availability.Size = new System.Drawing.Size(169, 47);
            this.Availability.TabIndex = 15;
            this.Availability.Text = "Availability";
            this.Availability.UseVisualStyleBackColor = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Tan;
            this.panel3.Controls.Add(this.lblTotalInvoicePrice);
            this.panel3.Controls.Add(this.lblVat);
            this.panel3.Controls.Add(this.lblSubTotalInvoicePrice);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Location = new System.Drawing.Point(1, 306);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(296, 201);
            this.panel3.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 126);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Total";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(28, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "VAT";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Sub Total";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tabControl1);
            this.panel1.Location = new System.Drawing.Point(241, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(778, 288);
            this.panel1.TabIndex = 7;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.ProdList);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(7, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(772, 282);
            this.tabControl1.TabIndex = 0;
            // 
            // ProdList
            // 
            this.ProdList.BackColor = System.Drawing.Color.Tan;
            this.ProdList.Controls.Add(this.btnAddToInvoice);
            this.ProdList.Controls.Add(this.txtQuantity);
            this.ProdList.Controls.Add(this.txtSearch);
            this.ProdList.Controls.Add(this.label10);
            this.ProdList.Controls.Add(this.lblPrice);
            this.ProdList.Controls.Add(this.lblProductName);
            this.ProdList.Controls.Add(this.lblProductId);
            this.ProdList.Controls.Add(this.lblUnitsInStock);
            this.ProdList.Controls.Add(this.lblActualPrice);
            this.ProdList.Controls.Add(this.label8);
            this.ProdList.Controls.Add(this.label7);
            this.ProdList.Controls.Add(this.dgProducts);
            this.ProdList.Location = new System.Drawing.Point(4, 22);
            this.ProdList.Name = "ProdList";
            this.ProdList.Padding = new System.Windows.Forms.Padding(3);
            this.ProdList.Size = new System.Drawing.Size(764, 256);
            this.ProdList.TabIndex = 0;
            this.ProdList.Text = "Product List";
            // 
            // btnAddToInvoice
            // 
            this.btnAddToInvoice.BackColor = System.Drawing.Color.SaddleBrown;
            this.btnAddToInvoice.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddToInvoice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddToInvoice.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.btnAddToInvoice.Location = new System.Drawing.Point(534, 129);
            this.btnAddToInvoice.Name = "btnAddToInvoice";
            this.btnAddToInvoice.Size = new System.Drawing.Size(136, 23);
            this.btnAddToInvoice.TabIndex = 6;
            this.btnAddToInvoice.Text = "Add To Invoice";
            this.btnAddToInvoice.UseVisualStyleBackColor = false;
            this.btnAddToInvoice.Click += new System.EventHandler(this.btnAddToInvoice_Click);
            // 
            // txtQuantity
            // 
            this.txtQuantity.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtQuantity.Location = new System.Drawing.Point(534, 103);
            this.txtQuantity.Name = "txtQuantity";
            this.txtQuantity.Size = new System.Drawing.Size(75, 20);
            this.txtQuantity.TabIndex = 5;
            // 
            // txtSearch
            // 
            this.txtSearch.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtSearch.Location = new System.Drawing.Point(6, 16);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(225, 20);
            this.txtSearch.TabIndex = 3;
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(479, 76);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(31, 13);
            this.label10.TabIndex = 2;
            this.label10.Text = "Price";
            // 
            // lblPrice
            // 
            this.lblPrice.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice.Location = new System.Drawing.Point(534, 54);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(219, 35);
            this.lblPrice.TabIndex = 2;
            this.lblPrice.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblProductName
            // 
            this.lblProductName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblProductName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProductName.Location = new System.Drawing.Point(534, 6);
            this.lblProductName.Name = "lblProductName";
            this.lblProductName.Size = new System.Drawing.Size(219, 35);
            this.lblProductName.TabIndex = 2;
            this.lblProductName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblProductId
            // 
            this.lblProductId.AutoSize = true;
            this.lblProductId.Location = new System.Drawing.Point(531, 161);
            this.lblProductId.Name = "lblProductId";
            this.lblProductId.Size = new System.Drawing.Size(55, 13);
            this.lblProductId.TabIndex = 2;
            this.lblProductId.Text = "ProductID";
            this.lblProductId.Visible = false;
            // 
            // lblUnitsInStock
            // 
            this.lblUnitsInStock.AutoSize = true;
            this.lblUnitsInStock.Location = new System.Drawing.Point(531, 190);
            this.lblUnitsInStock.Name = "lblUnitsInStock";
            this.lblUnitsInStock.Size = new System.Drawing.Size(68, 13);
            this.lblUnitsInStock.TabIndex = 2;
            this.lblUnitsInStock.Text = "UnitsInStock";
            this.lblUnitsInStock.Visible = false;
            // 
            // lblActualPrice
            // 
            this.lblActualPrice.AutoSize = true;
            this.lblActualPrice.Location = new System.Drawing.Point(631, 161);
            this.lblActualPrice.Name = "lblActualPrice";
            this.lblActualPrice.Size = new System.Drawing.Size(64, 13);
            this.lblActualPrice.TabIndex = 2;
            this.lblActualPrice.Text = "Actual Price";
            this.lblActualPrice.Visible = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(484, 28);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 13);
            this.label8.TabIndex = 2;
            this.label8.Text = "Product";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(479, 110);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 13);
            this.label7.TabIndex = 2;
            this.label7.Text = "Quantity:";
            // 
            // dgProducts
            // 
            this.dgProducts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgProducts.GridColor = System.Drawing.Color.LightSalmon;
            this.dgProducts.Location = new System.Drawing.Point(6, 42);
            this.dgProducts.Name = "dgProducts";
            this.dgProducts.Size = new System.Drawing.Size(467, 174);
            this.dgProducts.TabIndex = 0;
            this.dgProducts.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgProducts_CellClick);
            this.dgProducts.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgProducts_CellContentClick);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Tan;
            this.tabPage2.Controls.Add(this.dgInvoicing);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(764, 256);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Invoicing";
            // 
            // orderBindingSource
            // 
            this.orderBindingSource.DataMember = "Order";
            this.orderBindingSource.DataSource = this.dataSet1;
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "DataSet1";
            this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btn1
            // 
            this.btn1.BackColor = System.Drawing.Color.Wheat;
            this.btn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn1.Location = new System.Drawing.Point(5, 11);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(65, 52);
            this.btn1.TabIndex = 0;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = false;
            // 
            // btn2
            // 
            this.btn2.BackColor = System.Drawing.Color.Wheat;
            this.btn2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn2.Location = new System.Drawing.Point(82, 11);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(65, 52);
            this.btn2.TabIndex = 1;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = false;
            // 
            // btn3
            // 
            this.btn3.BackColor = System.Drawing.Color.Wheat;
            this.btn3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn3.Location = new System.Drawing.Point(165, 11);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(65, 52);
            this.btn3.TabIndex = 2;
            this.btn3.Text = "3";
            this.btn3.UseVisualStyleBackColor = false;
            // 
            // btn4
            // 
            this.btn4.BackColor = System.Drawing.Color.Wheat;
            this.btn4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn4.Location = new System.Drawing.Point(5, 79);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(65, 52);
            this.btn4.TabIndex = 3;
            this.btn4.Text = "4";
            this.btn4.UseVisualStyleBackColor = false;
            // 
            // btn5
            // 
            this.btn5.BackColor = System.Drawing.Color.Wheat;
            this.btn5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn5.Location = new System.Drawing.Point(82, 79);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(65, 52);
            this.btn5.TabIndex = 4;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = false;
            // 
            // btn6
            // 
            this.btn6.BackColor = System.Drawing.Color.Wheat;
            this.btn6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn6.Location = new System.Drawing.Point(165, 79);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(65, 52);
            this.btn6.TabIndex = 5;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = false;
            // 
            // btn7
            // 
            this.btn7.BackColor = System.Drawing.Color.Wheat;
            this.btn7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn7.Location = new System.Drawing.Point(5, 147);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(65, 52);
            this.btn7.TabIndex = 6;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = false;
            // 
            // btn8
            // 
            this.btn8.BackColor = System.Drawing.Color.Wheat;
            this.btn8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn8.Location = new System.Drawing.Point(82, 147);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(65, 52);
            this.btn8.TabIndex = 7;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = false;
            // 
            // btn9
            // 
            this.btn9.BackColor = System.Drawing.Color.Wheat;
            this.btn9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn9.Location = new System.Drawing.Point(165, 147);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(65, 52);
            this.btn9.TabIndex = 8;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = false;
            // 
            // btnDot
            // 
            this.btnDot.BackColor = System.Drawing.Color.Wheat;
            this.btnDot.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDot.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDot.Location = new System.Drawing.Point(5, 215);
            this.btnDot.Name = "btnDot";
            this.btnDot.Size = new System.Drawing.Size(65, 52);
            this.btnDot.TabIndex = 9;
            this.btnDot.Text = ".";
            this.btnDot.UseVisualStyleBackColor = false;
            // 
            // btn0
            // 
            this.btn0.BackColor = System.Drawing.Color.Wheat;
            this.btn0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn0.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn0.Location = new System.Drawing.Point(82, 215);
            this.btn0.Name = "btn0";
            this.btn0.Size = new System.Drawing.Size(65, 52);
            this.btn0.TabIndex = 10;
            this.btn0.Text = "0";
            this.btn0.UseVisualStyleBackColor = false;
            // 
            // btnC
            // 
            this.btnC.BackColor = System.Drawing.Color.Wheat;
            this.btnC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnC.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnC.Location = new System.Drawing.Point(166, 215);
            this.btnC.Name = "btnC";
            this.btnC.Size = new System.Drawing.Size(65, 52);
            this.btnC.TabIndex = 11;
            this.btnC.Text = "C";
            this.btnC.UseVisualStyleBackColor = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FloralWhite;
            this.panel2.Controls.Add(this.btnC);
            this.panel2.Controls.Add(this.btn0);
            this.panel2.Controls.Add(this.btnDot);
            this.panel2.Controls.Add(this.btn9);
            this.panel2.Controls.Add(this.btn8);
            this.panel2.Controls.Add(this.btn7);
            this.panel2.Controls.Add(this.btn6);
            this.panel2.Controls.Add(this.btn5);
            this.panel2.Controls.Add(this.btn4);
            this.panel2.Controls.Add(this.btn3);
            this.panel2.Controls.Add(this.btn2);
            this.panel2.Controls.Add(this.btn1);
            this.panel2.Location = new System.Drawing.Point(1, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(241, 288);
            this.panel2.TabIndex = 8;
            // 
            // orderTableAdapter
            // 
            this.orderTableAdapter.ClearBeforeFill = true;
            // 
            // orderLineBindingSource
            // 
            this.orderLineBindingSource.DataMember = "OrderLine";
            this.orderLineBindingSource.DataSource = this.dataSet1;
            // 
            // orderLineTableAdapter
            // 
            this.orderLineTableAdapter.ClearBeforeFill = true;
            // 
            // dgInvoicing
            // 
            this.dgInvoicing.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgInvoicing.GridColor = System.Drawing.Color.LightSalmon;
            this.dgInvoicing.Location = new System.Drawing.Point(10, 17);
            this.dgInvoicing.Name = "dgInvoicing";
            this.dgInvoicing.Size = new System.Drawing.Size(743, 134);
            this.dgInvoicing.TabIndex = 1;
            // 
            // lblSubTotalInvoicePrice
            // 
            this.lblSubTotalInvoicePrice.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSubTotalInvoicePrice.Location = new System.Drawing.Point(110, 12);
            this.lblSubTotalInvoicePrice.Name = "lblSubTotalInvoicePrice";
            this.lblSubTotalInvoicePrice.Size = new System.Drawing.Size(153, 23);
            this.lblSubTotalInvoicePrice.TabIndex = 2;
            // 
            // lblVat
            // 
            this.lblVat.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblVat.Location = new System.Drawing.Point(110, 68);
            this.lblVat.Name = "lblVat";
            this.lblVat.Size = new System.Drawing.Size(153, 23);
            this.lblVat.TabIndex = 2;
            // 
            // lblTotalInvoicePrice
            // 
            this.lblTotalInvoicePrice.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotalInvoicePrice.Location = new System.Drawing.Point(110, 120);
            this.lblTotalInvoicePrice.Name = "lblTotalInvoicePrice";
            this.lblTotalInvoicePrice.Size = new System.Drawing.Size(153, 23);
            this.lblTotalInvoicePrice.TabIndex = 2;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1023, 519);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.ProdList.ResumeLayout(false);
            this.ProdList.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgProducts)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.orderBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.orderLineBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgInvoicing)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.ComboBox cmbPayMethod;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox lblChange;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox Cost;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button NewCustomer;
        private System.Windows.Forms.Button Pay;
        private System.Windows.Forms.Button Remove;
        private System.Windows.Forms.Button Print;
        private System.Windows.Forms.Button Reset;
        private System.Windows.Forms.Button Availability;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage ProdList;
        private System.Windows.Forms.Button btnAddToInvoice;
        private System.Windows.Forms.TextBox txtQuantity;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView dgProducts;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btnDot;
        private System.Windows.Forms.Button btn0;
        private System.Windows.Forms.Button btnC;
        private System.Windows.Forms.Panel panel2;
        private EventHandler SearchBtn_Click;
        private DataSet1 dataSet1;
        private System.Windows.Forms.BindingSource orderBindingSource;
        private DataSet1TableAdapters.OrderTableAdapter orderTableAdapter;
        private System.Windows.Forms.BindingSource orderLineBindingSource;
        private DataSet1TableAdapters.OrderLineTableAdapter orderLineTableAdapter;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblProductName;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblUnitsInStock;
        private System.Windows.Forms.Label lblActualPrice;
        private System.Windows.Forms.Label lblProductId;
        private System.Windows.Forms.DataGridView dgInvoicing;
        private System.Windows.Forms.Label lblSubTotalInvoicePrice;
        private System.Windows.Forms.Label lblTotalInvoicePrice;
        private System.Windows.Forms.Label lblVat;

        public EventHandler cmbPayMethod_SelectedIndexChanged { get; private set; }
    }
}