﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS_Project
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void processOrderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void suppliersToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void searchCustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Form4().Show();
            this.Hide();
        }

        private void manageSuppliersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Form5().Show();
            this.Hide();
        }

        private void manageEmployeesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Form6().Show();
            this.Hide();
        }
    }
}
