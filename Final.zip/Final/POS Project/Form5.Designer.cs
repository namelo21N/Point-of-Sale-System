﻿namespace POS_Project
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label supplierIDLabel;
            System.Windows.Forms.Label company_NameLabel;
            System.Windows.Forms.Label street_AddressLabel;
            System.Windows.Forms.Label city_NameLabel;
            System.Windows.Forms.Label city_CodeLabel;
            System.Windows.Forms.Label email_AddressLabel;
            System.Windows.Forms.Label contact_NumberLabel;
            System.Windows.Forms.Label supplier_TypeLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form5));
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.supplierBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet1 = new POS_Project.DataSet1();
            this.panel2 = new System.Windows.Forms.Panel();
            this.supplierIDTextBox = new System.Windows.Forms.TextBox();
            this.supplierBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.supplierDataSet = new POS_Project.SupplierDataSet();
            this.company_NameTextBox = new System.Windows.Forms.TextBox();
            this.street_AddressTextBox = new System.Windows.Forms.TextBox();
            this.city_NameTextBox = new System.Windows.Forms.TextBox();
            this.city_CodeTextBox = new System.Windows.Forms.TextBox();
            this.email_AddressTextBox = new System.Windows.Forms.TextBox();
            this.contact_NumberTextBox = new System.Windows.Forms.TextBox();
            this.supplier_TypeTextBox = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.supplierTableAdapter = new POS_Project.DataSet1TableAdapters.SupplierTableAdapter();
            this.supplierDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.searchSupplierToolStrip = new System.Windows.Forms.ToolStrip();
            this.supplier_TypeToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.supplier_TypeToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.searchSupplierToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.supplierTableAdapter1 = new POS_Project.SupplierDataSetTableAdapters.SupplierTableAdapter();
            this.tableAdapterManager = new POS_Project.SupplierDataSetTableAdapters.TableAdapterManager();
            this.button5 = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            supplierIDLabel = new System.Windows.Forms.Label();
            company_NameLabel = new System.Windows.Forms.Label();
            street_AddressLabel = new System.Windows.Forms.Label();
            city_NameLabel = new System.Windows.Forms.Label();
            city_CodeLabel = new System.Windows.Forms.Label();
            email_AddressLabel = new System.Windows.Forms.Label();
            contact_NumberLabel = new System.Windows.Forms.Label();
            supplier_TypeLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.supplierBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.supplierBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supplierDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supplierDataGridView)).BeginInit();
            this.searchSupplierToolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // supplierIDLabel
            // 
            supplierIDLabel.AutoSize = true;
            supplierIDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            supplierIDLabel.Location = new System.Drawing.Point(21, 34);
            supplierIDLabel.Name = "supplierIDLabel";
            supplierIDLabel.Size = new System.Drawing.Size(71, 15);
            supplierIDLabel.TabIndex = 21;
            supplierIDLabel.Text = "Supplier ID:";
            // 
            // company_NameLabel
            // 
            company_NameLabel.AutoSize = true;
            company_NameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            company_NameLabel.Location = new System.Drawing.Point(21, 71);
            company_NameLabel.Name = "company_NameLabel";
            company_NameLabel.Size = new System.Drawing.Size(99, 15);
            company_NameLabel.TabIndex = 23;
            company_NameLabel.Text = "Company Name:";
            // 
            // street_AddressLabel
            // 
            street_AddressLabel.AutoSize = true;
            street_AddressLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            street_AddressLabel.Location = new System.Drawing.Point(21, 111);
            street_AddressLabel.Name = "street_AddressLabel";
            street_AddressLabel.Size = new System.Drawing.Size(89, 15);
            street_AddressLabel.TabIndex = 25;
            street_AddressLabel.Text = "Street Address:";
            // 
            // city_NameLabel
            // 
            city_NameLabel.AutoSize = true;
            city_NameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            city_NameLabel.Location = new System.Drawing.Point(21, 149);
            city_NameLabel.Name = "city_NameLabel";
            city_NameLabel.Size = new System.Drawing.Size(66, 15);
            city_NameLabel.TabIndex = 27;
            city_NameLabel.Text = "City Name:";
            // 
            // city_CodeLabel
            // 
            city_CodeLabel.AutoSize = true;
            city_CodeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            city_CodeLabel.Location = new System.Drawing.Point(21, 185);
            city_CodeLabel.Name = "city_CodeLabel";
            city_CodeLabel.Size = new System.Drawing.Size(61, 15);
            city_CodeLabel.TabIndex = 29;
            city_CodeLabel.Text = "City Code:";
            // 
            // email_AddressLabel
            // 
            email_AddressLabel.AutoSize = true;
            email_AddressLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            email_AddressLabel.Location = new System.Drawing.Point(21, 222);
            email_AddressLabel.Name = "email_AddressLabel";
            email_AddressLabel.Size = new System.Drawing.Size(89, 15);
            email_AddressLabel.TabIndex = 31;
            email_AddressLabel.Text = "Email Address:";
            // 
            // contact_NumberLabel
            // 
            contact_NumberLabel.AutoSize = true;
            contact_NumberLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            contact_NumberLabel.Location = new System.Drawing.Point(21, 257);
            contact_NumberLabel.Name = "contact_NumberLabel";
            contact_NumberLabel.Size = new System.Drawing.Size(99, 15);
            contact_NumberLabel.TabIndex = 33;
            contact_NumberLabel.Text = "Contact Number:";
            // 
            // supplier_TypeLabel
            // 
            supplier_TypeLabel.AutoSize = true;
            supplier_TypeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            supplier_TypeLabel.Location = new System.Drawing.Point(21, 291);
            supplier_TypeLabel.Name = "supplier_TypeLabel";
            supplier_TypeLabel.Size = new System.Drawing.Size(85, 15);
            supplier_TypeLabel.TabIndex = 35;
            supplier_TypeLabel.Text = "Supplier Type:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Tan;
            this.label1.Font = new System.Drawing.Font("Sitka Subheading", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(350, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(306, 42);
            this.label1.TabIndex = 23;
            this.label1.Text = "Supplier Information";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.SaddleBrown;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.button1.Location = new System.Drawing.Point(335, 102);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 22;
            this.button1.Text = "Search";
            this.toolTip1.SetToolTip(this.button1, "Search by Type");
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.AntiqueWhite;
            this.textBox1.Location = new System.Drawing.Point(429, 105);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(142, 20);
            this.textBox1.TabIndex = 21;
            // 
            // supplierBindingSource
            // 
            this.supplierBindingSource.DataMember = "Supplier";
            this.supplierBindingSource.DataSource = this.dataSet1;
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "DataSet1";
            this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Tan;
            this.panel2.Controls.Add(supplierIDLabel);
            this.panel2.Controls.Add(this.supplierIDTextBox);
            this.panel2.Controls.Add(company_NameLabel);
            this.panel2.Controls.Add(this.company_NameTextBox);
            this.panel2.Controls.Add(street_AddressLabel);
            this.panel2.Controls.Add(this.street_AddressTextBox);
            this.panel2.Controls.Add(city_NameLabel);
            this.panel2.Controls.Add(this.city_NameTextBox);
            this.panel2.Controls.Add(city_CodeLabel);
            this.panel2.Controls.Add(this.city_CodeTextBox);
            this.panel2.Controls.Add(email_AddressLabel);
            this.panel2.Controls.Add(this.email_AddressTextBox);
            this.panel2.Controls.Add(contact_NumberLabel);
            this.panel2.Controls.Add(this.contact_NumberTextBox);
            this.panel2.Controls.Add(supplier_TypeLabel);
            this.panel2.Controls.Add(this.supplier_TypeTextBox);
            this.panel2.Controls.Add(this.button4);
            this.panel2.Controls.Add(this.button3);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Location = new System.Drawing.Point(12, 97);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(275, 400);
            this.panel2.TabIndex = 24;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // supplierIDTextBox
            // 
            this.supplierIDTextBox.BackColor = System.Drawing.Color.AntiqueWhite;
            this.supplierIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.supplierBindingSource1, "SupplierID", true));
            this.supplierIDTextBox.Location = new System.Drawing.Point(140, 33);
            this.supplierIDTextBox.Name = "supplierIDTextBox";
            this.supplierIDTextBox.Size = new System.Drawing.Size(100, 20);
            this.supplierIDTextBox.TabIndex = 22;
            // 
            // supplierBindingSource1
            // 
            this.supplierBindingSource1.DataMember = "Supplier";
            this.supplierBindingSource1.DataSource = this.supplierDataSet;
            // 
            // supplierDataSet
            // 
            this.supplierDataSet.DataSetName = "SupplierDataSet";
            this.supplierDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // company_NameTextBox
            // 
            this.company_NameTextBox.BackColor = System.Drawing.Color.AntiqueWhite;
            this.company_NameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.supplierBindingSource1, "Company_Name", true));
            this.company_NameTextBox.Location = new System.Drawing.Point(140, 70);
            this.company_NameTextBox.Name = "company_NameTextBox";
            this.company_NameTextBox.Size = new System.Drawing.Size(100, 20);
            this.company_NameTextBox.TabIndex = 24;
            // 
            // street_AddressTextBox
            // 
            this.street_AddressTextBox.BackColor = System.Drawing.Color.AntiqueWhite;
            this.street_AddressTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.supplierBindingSource1, "Street_Address", true));
            this.street_AddressTextBox.Location = new System.Drawing.Point(140, 110);
            this.street_AddressTextBox.Name = "street_AddressTextBox";
            this.street_AddressTextBox.Size = new System.Drawing.Size(100, 20);
            this.street_AddressTextBox.TabIndex = 26;
            // 
            // city_NameTextBox
            // 
            this.city_NameTextBox.BackColor = System.Drawing.Color.AntiqueWhite;
            this.city_NameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.supplierBindingSource1, "City_Name", true));
            this.city_NameTextBox.Location = new System.Drawing.Point(140, 148);
            this.city_NameTextBox.Name = "city_NameTextBox";
            this.city_NameTextBox.Size = new System.Drawing.Size(100, 20);
            this.city_NameTextBox.TabIndex = 28;
            // 
            // city_CodeTextBox
            // 
            this.city_CodeTextBox.BackColor = System.Drawing.Color.AntiqueWhite;
            this.city_CodeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.supplierBindingSource1, "City_Code", true));
            this.city_CodeTextBox.Location = new System.Drawing.Point(140, 184);
            this.city_CodeTextBox.Name = "city_CodeTextBox";
            this.city_CodeTextBox.Size = new System.Drawing.Size(100, 20);
            this.city_CodeTextBox.TabIndex = 30;
            // 
            // email_AddressTextBox
            // 
            this.email_AddressTextBox.BackColor = System.Drawing.Color.AntiqueWhite;
            this.email_AddressTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.supplierBindingSource1, "Email_Address", true));
            this.email_AddressTextBox.Location = new System.Drawing.Point(140, 221);
            this.email_AddressTextBox.Name = "email_AddressTextBox";
            this.email_AddressTextBox.Size = new System.Drawing.Size(100, 20);
            this.email_AddressTextBox.TabIndex = 32;
            // 
            // contact_NumberTextBox
            // 
            this.contact_NumberTextBox.BackColor = System.Drawing.Color.AntiqueWhite;
            this.contact_NumberTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.supplierBindingSource1, "Contact_Number", true));
            this.contact_NumberTextBox.Location = new System.Drawing.Point(140, 256);
            this.contact_NumberTextBox.Name = "contact_NumberTextBox";
            this.contact_NumberTextBox.Size = new System.Drawing.Size(100, 20);
            this.contact_NumberTextBox.TabIndex = 34;
            // 
            // supplier_TypeTextBox
            // 
            this.supplier_TypeTextBox.BackColor = System.Drawing.Color.AntiqueWhite;
            this.supplier_TypeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.supplierBindingSource1, "Supplier_Type", true));
            this.supplier_TypeTextBox.Location = new System.Drawing.Point(140, 290);
            this.supplier_TypeTextBox.Name = "supplier_TypeTextBox";
            this.supplier_TypeTextBox.Size = new System.Drawing.Size(100, 20);
            this.supplier_TypeTextBox.TabIndex = 36;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.SaddleBrown;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.button4.Location = new System.Drawing.Point(191, 350);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(81, 30);
            this.button4.TabIndex = 21;
            this.button4.Text = "Remove";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.SaddleBrown;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.button3.Location = new System.Drawing.Point(100, 350);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(85, 30);
            this.button3.TabIndex = 20;
            this.button3.Text = "Save";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.SaddleBrown;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.button2.Location = new System.Drawing.Point(8, 350);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(84, 30);
            this.button2.TabIndex = 12;
            this.button2.Text = "Add New";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // supplierTableAdapter
            // 
            this.supplierTableAdapter.ClearBeforeFill = true;
            // 
            // supplierDataGridView
            // 
            this.supplierDataGridView.AutoGenerateColumns = false;
            this.supplierDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.supplierDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8});
            this.supplierDataGridView.DataSource = this.supplierBindingSource1;
            this.supplierDataGridView.GridColor = System.Drawing.Color.Tan;
            this.supplierDataGridView.Location = new System.Drawing.Point(293, 131);
            this.supplierDataGridView.Name = "supplierDataGridView";
            this.supplierDataGridView.Size = new System.Drawing.Size(743, 313);
            this.supplierDataGridView.TabIndex = 24;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "SupplierID";
            this.dataGridViewTextBoxColumn1.HeaderText = "SupplierID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Company_Name";
            this.dataGridViewTextBoxColumn2.HeaderText = "Company_Name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Street_Address";
            this.dataGridViewTextBoxColumn3.HeaderText = "Street_Address";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "City_Name";
            this.dataGridViewTextBoxColumn4.HeaderText = "City_Name";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "City_Code";
            this.dataGridViewTextBoxColumn5.HeaderText = "City_Code";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Email_Address";
            this.dataGridViewTextBoxColumn6.HeaderText = "Email_Address";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Contact_Number";
            this.dataGridViewTextBoxColumn7.HeaderText = "Contact_Number";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Supplier_Type";
            this.dataGridViewTextBoxColumn8.HeaderText = "Supplier_Type";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // searchSupplierToolStrip
            // 
            this.searchSupplierToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.supplier_TypeToolStripLabel,
            this.supplier_TypeToolStripTextBox,
            this.searchSupplierToolStripButton});
            this.searchSupplierToolStrip.Location = new System.Drawing.Point(0, 0);
            this.searchSupplierToolStrip.Name = "searchSupplierToolStrip";
            this.searchSupplierToolStrip.Size = new System.Drawing.Size(1087, 25);
            this.searchSupplierToolStrip.TabIndex = 25;
            this.searchSupplierToolStrip.Text = "searchSupplierToolStrip";
            this.searchSupplierToolStrip.Visible = false;
            // 
            // supplier_TypeToolStripLabel
            // 
            this.supplier_TypeToolStripLabel.Name = "supplier_TypeToolStripLabel";
            this.supplier_TypeToolStripLabel.Size = new System.Drawing.Size(82, 22);
            this.supplier_TypeToolStripLabel.Text = "Supplier_Type:";
            // 
            // supplier_TypeToolStripTextBox
            // 
            this.supplier_TypeToolStripTextBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.supplier_TypeToolStripTextBox.Name = "supplier_TypeToolStripTextBox";
            this.supplier_TypeToolStripTextBox.Size = new System.Drawing.Size(100, 25);
            // 
            // searchSupplierToolStripButton
            // 
            this.searchSupplierToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.searchSupplierToolStripButton.Name = "searchSupplierToolStripButton";
            this.searchSupplierToolStripButton.Size = new System.Drawing.Size(89, 22);
            this.searchSupplierToolStripButton.Text = "SearchSupplier";
            this.searchSupplierToolStripButton.Click += new System.EventHandler(this.searchSupplierToolStripButton_Click);
            // 
            // supplierTableAdapter1
            // 
            this.supplierTableAdapter1.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.SupplierTableAdapter = this.supplierTableAdapter1;
            this.tableAdapterManager.UpdateOrder = POS_Project.SupplierDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.SaddleBrown;
            this.button5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button5.BackgroundImage")));
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button5.Location = new System.Drawing.Point(996, 9);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(40, 30);
            this.button5.TabIndex = 26;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // toolTip1
            // 
            this.toolTip1.ToolTipTitle = "Search by Supplier Type";
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1087, 519);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.searchSupplierToolStrip);
            this.Controls.Add(this.supplierDataGridView);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox1);
            this.Name = "Form5";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form5";
            this.Load += new System.EventHandler(this.Form5_Load);
            ((System.ComponentModel.ISupportInitialize)(this.supplierBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.supplierBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supplierDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supplierDataGridView)).EndInit();
            this.searchSupplierToolStrip.ResumeLayout(false);
            this.searchSupplierToolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private DataSet1 dataSet1;
        private System.Windows.Forms.BindingSource supplierBindingSource;
        private DataSet1TableAdapters.SupplierTableAdapter supplierTableAdapter;
        private SupplierDataSet supplierDataSet;
        private System.Windows.Forms.BindingSource supplierBindingSource1;
        private SupplierDataSetTableAdapters.SupplierTableAdapter supplierTableAdapter1;
        private SupplierDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TextBox supplierIDTextBox;
        private System.Windows.Forms.TextBox company_NameTextBox;
        private System.Windows.Forms.TextBox street_AddressTextBox;
        private System.Windows.Forms.TextBox city_NameTextBox;
        private System.Windows.Forms.TextBox city_CodeTextBox;
        private System.Windows.Forms.TextBox email_AddressTextBox;
        private System.Windows.Forms.TextBox contact_NumberTextBox;
        private System.Windows.Forms.TextBox supplier_TypeTextBox;
        private System.Windows.Forms.DataGridView supplierDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.ToolStrip searchSupplierToolStrip;
        private System.Windows.Forms.ToolStripLabel supplier_TypeToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox supplier_TypeToolStripTextBox;
        private System.Windows.Forms.ToolStripButton searchSupplierToolStripButton;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}